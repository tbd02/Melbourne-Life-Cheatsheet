library(shiny)
library("shiny")
library(ggplot2)
library(plotly)
library(leaflet)
library(dplyr)
library(tidyr)
library(sf)
library(shinyTime)
library(mapsapi)
library(DT)
####################
# Prepare the data #
####################
house_price <- read.csv('House_Prices_by_Small_Area_-_Sale_Year.csv')
small_area <- read.csv('Census_of_Land_Use_and_Employment__CLUE__Suburb.csv')
colnames(small_area)[2] <- 'Small_Area'
house_price <- house_price[complete.cases(house_price$Small_Area),]
house_price <- merge(house_price, small_area, by='Small_Area', all.x=TRUE)


business <- read.csv('Business_establishments__with_address_and_industry.csv')
a<- business[business$Industry..ANZSIC4..description == "Cafes and Restaurants", ]
b<- business[business$Industry..ANZSIC4..description == "Parking Services", ]
c<- business[business$Industry..ANZSIC4..description == "Health and Fitness Centres and Gymnasia Operation", ]
d<- business[business$Industry..ANZSIC4..description == "Pubs, Taverns and Bars", ]
business = data.frame(rbind(a,b,c,d))

#import data
df <- read.csv("Landmarksandplacesofinterestin.csv")
#get the frequency of each theme
themes <- df %>% group_by(Theme)  %>%
  summarise(Frequency = n(),
            .groups = 'drop')

#remove punctuations
df$Co.ordinates <- gsub("\\(|\\)", "", df$Co.ordinates)
dfx <- separate(data = df, col = Co.ordinates, into = c("Latitude", "Longitude"), sep = ",")
#convert lat and longitude to numeric, set digits to 20 to ensure no reduction of decimals
options(digits=20)
dfx$Latitude <- as.numeric(dfx$Latitude)
options(digits=20)
dfx$Longitude <- as.numeric(dfx$Longitude)


#create icons for the themes
#transport
transport <- makeIcon(
  iconUrl = "https://img.icons8.com/color/344/bus.png",
  iconWidth = 25*215/230,
  iconHeight = 15, 
  iconAnchorY = 15,
  iconAnchorX = 25*215/230/2)
#mixed use
mixed <- makeIcon(
  iconUrl = "https://img.icons8.com/ios-glyphs/344/manufacturing.png",
  iconWidth = 25*215/230,
  iconHeight = 25, 
  iconAnchorY = 16,
  iconAnchorX = 25*215/230/2)
#retail
retail <- makeIcon(
  iconUrl = "https://img.icons8.com/color/2x/shopping-mall.png",
  iconWidth = 25*215/230,
  iconHeight = 25, 
  iconAnchorY = 16,
  iconAnchorX = 25*215/230/2)
#assembly
assembly <-makeIcon(
  iconUrl = "https://img.icons8.com/ios-filled/344/collect.png",
  iconWidth = 25*215/230,
  iconHeight = 25, 
  iconAnchorY = 16,
  iconAnchorX = 25*215/230/2)
#recreation
leisure <-makeIcon(
  iconUrl = "https://img.icons8.com/emoji/2x/beach-with-umbrella.png",
  iconWidth = 25*215/230,
  iconHeight = 25, 
  iconAnchorY = 16,
  iconAnchorX = 25*215/230/2)
#church icon
worship <-makeIcon(
  iconUrl = "https://img.icons8.com/emoji/2x/church-emoji.png",
  iconWidth = 25*215/230,
  iconHeight = 25, 
  iconAnchorY = 16,
  iconAnchorX = 25*215/230/2)
#Health services
health <- makeIcon(
  iconUrl = "https://img.icons8.com/emoji/2x/hospital-emoji.png",
  iconWidth = 25*215/230,
  iconHeight = 15, 
  iconAnchorY = 15,
  iconAnchorX = 25*215/230/2)
#community
community <- makeIcon(
  iconUrl = "https://img.icons8.com/doodle/2x/community.png",
  iconWidth = 25*215/230,
  iconHeight = 25, 
  iconAnchorY = 16,
  iconAnchorX = 25*215/230/2)
#Education
education <-makeIcon(
  iconUrl = "https://img.icons8.com/emoji/2x/school-emoji.png",
  iconWidth = 25*215/230,
  iconHeight = 25, 
  iconAnchorY = 16,
  iconAnchorX = 25*215/230/2)
#Office
office <-makeIcon(
  iconUrl = "https://img.icons8.com/ios/2x/office.png",
  iconWidth = 25*215/230,
  iconHeight = 25, 
  iconAnchorY = 16,
  iconAnchorX = 25*215/230/2)
#Vacant land
land <-makeIcon(
  iconUrl = "https://img.icons8.com/external-line512-zulfa-mahendra/2x/external-land-metaverse-line512-zulfa-mahendra.png",
  iconWidth = 25*215/230,
  iconHeight = 25, 
  iconAnchorY = 16,
  iconAnchorX = 25*215/230/2)
#Purpose Built
purpose <- makeIcon(
  iconUrl = "https://img.icons8.com/external-wanicon-lineal-color-wanicon/2x/external-purpose-training-and-coaching-wanicon-lineal-color-wanicon.png",
  iconWidth = 25*215/230,
  iconHeight = 25, 
  iconAnchorY = 16,
  iconAnchorX = 25*215/230/2)
#Specialist Residential Accommodation
spe_accomodation <- makeIcon(
  iconUrl = "https://img.icons8.com/external-flaticons-lineal-color-flat-icons/2x/external-accomodation-vacation-planning-flaticons-lineal-color-flat-icons.png",
  iconWidth = 25*215/230,
  iconHeight = 25, 
  iconAnchorY = 16,
  iconAnchorX = 25*215/230/2)
#Residential Accommodation
res_accomodation <-makeIcon(
  iconUrl = "https://img.icons8.com/external-flaticons-lineal-color-flat-icons/2x/external-accomodation-digital-nomad-flaticons-lineal-color-flat-icons.png",
  iconWidth = 25*215/230,
  iconHeight = 25, 
  iconAnchorY = 16,
  iconAnchorX = 25*215/230/2)
#Industrial
industry <-makeIcon(
  iconUrl = "https://img.icons8.com/fluency/2x/manufacturing.png",
  iconWidth = 25*215/230,
  iconHeight = 25, 
  iconAnchorY = 16,
  iconAnchorX = 25*215/230/2)
#Warehouse/Store
warehouse <-makeIcon(
  iconUrl = "https://img.icons8.com/external-kiranshastry-lineal-color-kiranshastry/2x/external-warehouse-logistic-delivery-kiranshastry-lineal-color-kiranshastry.png",
  iconWidth = 25*215/230,
  iconHeight = 25, 
  iconAnchorY = 16,
  iconAnchorX = 25*215/230/2)
#Define the itemset for the icons
iconSet  = iconList(Transport=transport,        
                    `Mixed Use`= mixed,        
                    `Place Of Assembly` =	assembly,                   
                    `Leisure/Recreation`                   	=	leisure,                   
                    `Place of Worship` 	=	worship, 
                    `Health Services` 	=	health, 
                    `Community Use`    	=	community,    
                    Retail          	=	retail,   
                    `Education Centre`	=	education,
                    Office =	office,           
                    `Vacant Land` =	land,     
                    `Purpose Built` =	purpose,   
                    `Specialist Residential Accommodation`	=	spe_accomodation,
                    `Residential Accommodation` =	res_accomodation,            
                    Industrial =	industry,      
                    `Warehouse/Store` 	=	warehouse
)

themess <- df

vswitch <- 0 # initialise a swtich that will control status of the control panel and map displayed
##################
# USER INTERFACE #
##################
# Tab 1: Introduction



ui <- navbarPage("Data Interface", id="nav",
                 
                 tabPanel("Search House",
                          div(class="outer",
                              
                              tags$head(
                                # custome CSS to let the map take up the entire page
                                includeCSS("styles.css")
                              ),
                              leafletOutput("map_house", width="100%", height="100%"),
                              # the panel includes the map, control panels, and plots
                              absolutePanel(id = "controls", class = "panel panel-default", fixed = TRUE,
                                            draggable = FALSE, top = 60, left = "auto", right = 20, bottom = "auto",
                                            width = 700, height = "auto",
                                            
                                            h3('Choose a type'),
                                            selectInput(
                                              'type',
                                              label = 'Type',
                                              choices = c('Transaction Count'='transaction',
                                                          'Median Price'='median'
                                              ),
                                              selected = 'transaction'
                                            ),
                                            
                                            h3("House Type"),
                                            radioButtons(
                                              'house_type',
                                              label = 'House Type',
                                              choices = c("All",
                                                          "House/Townhouse",
                                                          "Residential Apartment"
                                              )),
                                            selected = "All",
                                            
                                            h3('Year'),
                                            selectInput(
                                              'year',
                                              label = 'Year',
                                              choices = c("2000",
                                                          "2001",
                                                          "2002",
                                                          "2003",
                                                          "2004",
                                                          "2005",
                                                          "2006",
                                                          "2007",
                                                          "2008",
                                                          "2009",
                                                          "2010",
                                                          "2011",
                                                          "2012",
                                                          "2013",
                                                          "2014",
                                                          "2015",
                                                          "2016"
                                              ),
                                              selected = '2016'
                                            ),
                                            plotlyOutput("line_chart"),
                              ) # absolutePanel ends
                          ) # div ends
                 ),# tabPanel ends
                 tabPanel("Search Route",
                          div(class="outer",
                              
                              tags$head(
                                # custome CSS to let the map take up the entire page
                                includeCSS("styles.css")
                              ),
                              leafletOutput("search_route", width="100%", height="100%"),
                              # the panel includes the map, control panels, and plots
                              absolutePanel(id = "controls", class = "panel panel-default", fixed = TRUE,
                                            draggable = FALSE, top = 60, left = 50, right ="auto", bottom = "auto",
                                            width = 1000, height = 152,
                                            
                                            
                                            
                                            fluidRow(column(6,textInput('origin',
                                                                        'Origin',
                                                                        value = "",
                                                                        width = NULL,
                                                                        placeholder = 'Where you are')),
                                                     
                                                     column(6,textInput('dest',
                                                                        'Destination',
                                                                        value = "",
                                                                        width = NULL,
                                                                        placeholder = 'Where you want to go')),
                                                     column(4,radioButtons(
                                                       'traffic',
                                                       label = 'traffic',
                                                       choices = c("bus",
                                                                   "train",
                                                                   "tram",
                                                                   "drive",
                                                                   "all public transit"
                                                                   
                                                       ),inline=T)),
                                                     column(2,timeInput("time_input", "Enter arrive time",
                                                                        value = Sys.time(), minute.steps = 1),
                                                     ),br(),br(), br(),br(),br(),
                                                     column(4,
                                                            actionButton("reset_time", "reset time")),
                                                     column(2,
                                                            actionButton("search", "Let's Go")),)
                                            
                                            
                              ),# absolutePanel ends
                              conditionalPanel( condition = "input.search",#only shows up when search clicked
                                                absolutePanel(id = "controls", class = "panel panel-default", fixed = TRUE,
                                                              draggable = FALSE,  top = 60, left = "auto", right =50, bottom = "auto",
                                                              width = 600, height = 700,
                                                              
                                                              
                                                              column(width = 6,
                                                                     h4("Travel Detail"),
                                                                     dataTableOutput("detail",width = "10%"),
                                                                     actionButton("alternatives", "Alternative way"),
                                                                     textOutput("text")),
                                                ))# absolutePanel ends
                          ) # div ends
                 ),
                 
                 #########################################
                 #########################################
                 tabPanel("Search facilities",
                          div(class="outer",
                              
                              tags$head(
                                # custome CSS to let the map take up the entire page
                                includeCSS("styles.css")
                              ),
                              
                              leafletOutput("map_facilities", width="100%", height="100%"),
                              absolutePanel(id = "controls", class = "panel panel-default", fixed = TRUE,
                                            draggable = FALSE, top = 60, left = "auto", right = 20, bottom = "auto",
                                            width = 700, height = "auto",
                                            h3('Switch'),
                                            actionButton("switch", "Seach Attraction Place"),
                                            conditionalPanel(condition = "input.switch % 2 == 0", h3('Select area')),
                                            conditionalPanel(
                                              condition = "input.switch % 2 == 0",
                                              selectInput(
                                                'CLUE.small.area',
                                                label = 'Type',
                                                choices = c(sort(unique(business$CLUE.small.area)))  ,
                                                selected = 'Melbourne (CBD)',
                                              )),
                                            conditionalPanel(
                                              condition = "input.switch % 2 == 0", 
                                              h3('Find public facilities')),
                                            conditionalPanel(
                                              condition = "input.switch % 2 == 0", 
                                              selectInput(
                                                'Industry..ANZSIC4..description',
                                                label = 'Type',
                                                choices = c('Select theme',
                                                            'Cafes and Restaurants',
                                                            'Parking Services',
                                                            'Health and Fitness Centres and Gymnasia Operation',
                                                            'Pubs, Taverns and Bars'
                                                ),
                                                selected = 'Select theme',
                                              )
                                            ),
                                            conditionalPanel(
                                              condition = "input.switch % 2 != 0",
                                              h3("Select a theme")
                                            ),
                                            conditionalPanel(
                                              condition = "input.switch % 2 != 0",
                                              checkboxGroupInput(
                                                "theme", 
                                                "Select themes to explore",  
                                                choices = unique(dfx$Theme), 
                                                selected = c("Transport", "Warehouse/Store")
                                                )
                                            ),    
                                            conditionalPanel(
                                              condition = "input.switch % 2 != 0",
                                              plotlyOutput("graph"),
                                            )

                              )
                          )
                 )
                 
) # navbarPage ends


################
# SHINY SERVER #
################

server <- function(input, output, session) {
  v <- reactiveValues(small_area = "Melbourne (CBD)", instructions = "")
  
  filter <- function(df){
    
    if (input$type == 'transaction') {
      data <- df[,c(1,2,3,5)]
      data$title <- "Transaction Count"
    } else {
      data <- df[,c(1,2,3,4)]
      data$title <- "Median Price"
    }
    if(input$house_type == 'House/Townhouse'){
      data <- data[data$Type=="House/Townhouse", ]
    }
    else if(input$house_type == 'Residential Apartment'){
      data <- data[data$Type == "Residential Apartment",]
    }
    else{
      data <- data
    }
    colnames(data)[4] <- 'obj'
    data <- data[complete.cases(data$obj),]
    
    return(data)
  }
  
  filterForHouseMap <- reactive({
    data <- st_as_sf(house_price, wkt = "the_geom")
    data <- data[data$Sale_Year == input$year, ]
    data <- filter(data)
    
    data$popup <- paste0('<font size="+2"><b>', data$Small_Area, '</b></font><br>',
                         '<b>', data$Sale_Year, '</b><br>',
                         '<font size="+1">', data$title, ": ", data$obj, '</font><br>'
    )
    data
  })
  
  
  output$map_house <- renderLeaflet({
    
    data <- filterForHouseMap()
    
    bins <- quantile(data$obj)
    pal <- colorBin("YlOrRd", domain = data$obj, bins = bins)
    
    leaflet() %>%
      setView(lng =	144.96036956449648869, lat=-37.811529070705475419, zoom=13) %>%
      addProviderTiles(providers$CartoDB)%>%
      addPolygons(
        data = data,
        fillColor = ~pal(obj),
        layerId = ~Small_Area,
        weight = 2,
        opacity = 1,
        color = "white",
        dashArray = "3",
        fillOpacity = 0.4,
        popup = ~popup,
        highlightOptions = highlightOptions(
          weight = 5,
          color = "#666",
          dashArray = "",
          fillOpacity = 0.7,
          bringToFront = TRUE))
  }) # renderLeaflet ends
  
  output$line_chart <- renderPlotly({
    data <- filter(house_price)
    data <- data[data$Small_Area == v$small_area, ]
    data <- data[order(data$Sale_Year),]
    
    fig <- plot_ly(
      data[data$Type == 'House/Townhouse',],
      x = ~Sale_Year, y = ~obj,
      type = 'scatter',
      mode = 'lines',
      showlegend = TRUE,
      name="House/Townhouse Median Price",
      source = "subset"
    ) 
    
    fig <- fig %>% add_trace(
      data = data[data$Type == 'Residential Apartment',],
      x = ~Sale_Year, y = ~obj, type = 'scatter',
      mode = 'lines',
      showlegend = TRUE,
      name="Residential Apartment Median Price") %>%
      layout(hovermode = 'x',
             legend = list(orientation = "h",   # show entries horizontally
                           xanchor = "center",  # use center of legend as anchor
                           x = 0.5,
                           y=-0.2))
    
    fig
  })
  
  updateMap <- observe({
    event.data <- event_data("plotly_click", source = "subset")
    year <- event.data$x[1]
    updateSelectInput(session,
                      'year',
                      selected = year)
    
  })
  
  observeEvent(input$map_house_shape_click, {
    click <- input$map_house_shape_click
    v$small_area <- click$id
    print(click)
  })
  
  #resrt the time to system time
  observeEvent(input$reset_time, {
    updateTimeInput(session, "time_input", value = Sys.time())})
  
  #when click search  or alternative, this search function works
  searchRoute <- eventReactive({input$search|input$alternatives}, {
    time=input$time_input
    #set default value from unimelb to cbd
    if(input$origin == ""){
      origin <- "university of melbourne"
    }
    else{
      origin <- paste(input$origin, 'melbourne')
    }
    if(input$dest == ""){
      dest <- "melbourne central"
    }
    else{
      dest <- paste(input$dest, 'melbourne')
    }
    if(input$traffic %in% c("bus","tram","train")){
      mode="transit"
      transit=input$traffic
    }
    else if (input$traffic=="driving"){
      mode="driving"
      transit=NULL
    }
    else{
      mode="transit"
      transit=c("bus", "subway", "train", "tram")
    }
    
    key="AIzaSyB84chXISSjUJ72z2s52_TnuyyW_Z_TbS4"
    doc = mp_directions(
      origin = origin,
      destination = dest,
      alternatives = TRUE,
      arrival_time = time,
      mode= mode,
      transit_mode=transit,
      key = key,
      quiet = TRUE
    )
    
    mp_get_segments(doc)
  })
  #plot a map without route
  output$search_route <- renderLeaflet({
    r <- searchRoute()
    leaflet(r) %>%
      addProviderTiles("CartoDB.DarkMatter")%>%
      setView(lat=-37.812175979147106,lng=144.96245084166554,zoom=10)
  })
  #get routes when click search
  observeEvent(input$search,{
    
    r <- searchRoute()
    v$instructions <- ""
    #index of 1st choice and alternative
    idx1=0
    idx2=0
    for(i in r$alternative_id){
      if(i ==1){idx1=idx1+1}
      if(i ==2){idx2=idx2+1}
    }
    
    t=Sys.time()-180
    for(i in r[1:idx1,1:13]$duration_s){
      t=t-i
    }
    #calculate Recommended departure time
    output$text=renderText(paste("Recommended departure time:",format(strptime(format(t, "%X"),"%H:%M:%S"),"%H:%M")))
    #output route detail
    output$detail<-renderDataTable({
      dt <- DT::datatable(
        get_table(r[1:idx1,1:13]),
        rownames = FALSE,
        options = list(autoWidth = TRUE,searching = FALSE,paging = FALSE)
      )
      #shows color when click route
      if(!is.na(v$instructions)){
        dt <- dt %>%
          formatStyle(
            'instructions', target = 'row',
            backgroundColor = styleEqual(c(v$instructions), c("#FAF5C2"))
          )
      }
      
      dt
    })
    #color of each segment of route
    pal <- colorNumeric(c( "#CCFBFE","#E9706C"), 1:length(unique(r$travel_mode)))
    time=format(strptime(format(input$time_input, "%X"),"%H:%M:%S"),'%H')
    map <- leaflet(r[1:idx1,1:13])
    #if it's day or night
    if (as.integer(time) >= 7 & as.integer(time) < 17 ){
      map <- map %>% addProviderTiles("CartoDB.Positron")
    }
    else{
      map <- map %>% addProviderTiles("CartoDB.DarkMatter")
    }
    #plot route
    output$search_route <- renderLeaflet({
      map %>%
        addPolylines(
          opacity = 1,
          weight = 7,
          layerId = ~instructions,
          color = ~pal(c(1:length(unique(travel_mode)))), popup = ~paste(instructions,duration_text))%>%
        addCircleMarkers(color="#A7A157",lng = unlist(st_cast(r$geometry[idx1], "POINT"))[length(unlist(st_cast(r$geometry[idx1], "POINT")))-1],
                         lat = unlist(st_cast(r$geometry[idx1], "POINT"))[length(unlist(st_cast(r$geometry[idx1], "POINT")))],
                         popup ="Destination")%>%
        addCircleMarkers(color="#43AA8B"
                         ,lng = unlist(st_cast(r$geometry[1], "POINT"))[1],
                         lat = unlist(st_cast(r$geometry[1], "POINT"))[2],
                         popup ="Start Point")
    })
  })
  #change to alternative detail if alternatives clicked
  observeEvent(input$alternatives,{
    r <- searchRoute()
    v$instructions <- ""
    
    idx1=0
    idx2=0
    for(i in r$alternative_id){
      if(i ==1){idx1=idx1+1}
      if(i ==2){idx2=idx2+1}}
    t=Sys.time()-180
    
    for(i in r[(idx1+1):(idx1+idx2),1:13]$duration_s){
      t=t-i
    }
    
    output$text=renderText(paste("Recommended departure time:",format(strptime(format(t, "%X"),"%H:%M:%S"),"%H:%M:%S")))
    
    output$detail<-renderDataTable({
      dt <- DT::datatable(
        get_table(r[(1+idx1):(idx1+idx2),1:13]),
        rownames = FALSE,
        options = list(autoWidth = TRUE,searching = FALSE,paging = FALSE)
      )
      
      if(!is.na(v$instructions)){
        dt <- dt %>%
          formatStyle(
            'instructions', target = 'row',
            backgroundColor = styleEqual(c(v$instructions),c("#FAF5C2"))
          )
      }
      
      dt
    })
    
    pal <- colorNumeric(c( "#CCFBFE","#E9706C"), 1:length(unique(r$travel_mode)))
    
    time=format(strptime(format(input$time_input, "%X"),"%H:%M:%S"),'%H')
    map <- leaflet(r[(idx1+1):(idx1+idx2),1:13])
    if (as.integer(time) >= 7 & as.integer(time) < 17 ){
      map <- map %>%
        addProviderTiles("CartoDB.Positron")
    }
    else{
      map <- map %>%
        addProviderTiles("CartoDB.DarkMatter")
    }
    
    output$search_route <- renderLeaflet({
      map %>%
        addPolylines(
          opacity = 1,
          weight = 7,
          layerId = ~instructions,
          color = ~pal(c(1:length(unique(travel_mode)))), popup = ~paste(instructions,duration_text))%>%
        addCircleMarkers(color="#A7A157",lng =~unlist(st_cast(geometry[idx2], "POINT"))[length(unlist(st_cast(geometry[idx2], "POINT")))-1],
                         lat = ~unlist(st_cast(geometry[idx2], "POINT"))[length(unlist(st_cast(geometry[idx2], "POINT")))],
                         popup ="Destination")%>%
        addCircleMarkers(color="#43AA8B"
                         ,lng = ~unlist(st_cast(geometry[1], "POINT"))[1],
                         lat = ~unlist(st_cast(geometry[1], "POINT"))[2],
                         popup ="Start Point")
    })
    
  })
  
  observeEvent(input$search_route_shape_click, {
    click <- input$search_route_shape_click
    v$instructions <- click$id
  })
  #process needed information on the table from google api result
  get_table<-function(data){
    df = data.frame(matrix(nrow = length(data$alternative_id), ncol = 4))
    colnames(df)=c("travel_mode","instructions","duration_time","distance")
    df$travel_mode=data$travel_mode
    df$instructions=data$instructions
    df$duration_time=data$duration_text
    df$distance=data$distance_text
    return(df)
  }
  

  filteredData <- reactive({
    data <- dplyr::filter(business,
           if (input$Industry..ANZSIC4..description== 'Select theme')TRUE
           else Industry..ANZSIC4..description == input$Industry..ANZSIC4..description,
           if (input$CLUE.small.area== 'Slelect Area')TRUE
           else CLUE.small.area == input$CLUE.small.area
    )
  })
  
  output$map_facilities <- renderLeaflet({
    print("hello")
    print(input$switch)
    vswitch <- input$switch
    print(vswitch)
    if(input$switch %% 2 == 0){
      data <- filteredData()
      
      data$popup <- paste0('<font size="+2"><b>', data$Industry..ANZSIC4..description, '</b></font><br>',
                           '<font size="+1">', data$CLUE.small.area, '</font><br>',
                           '<b>',"Location : ", data$Business.address,'</b><br>'
      )
      ## plot the map
      fig <- leaflet(data) %>%
        addProviderTiles(providers$CartoDB) %>%
        addAwesomeMarkers(~lat, ~lon,
                          icon=~awesomeIcons(icon=case_when(Industry..ANZSIC4..description == 'Cafes and Restaurants' ~ 'fa-cutlery',
                                                            Industry..ANZSIC4..description == 'Parking Services' ~ 'fa-car',
                                                            Industry..ANZSIC4..description == 'Health and Fitness Centres and Gymnasia Operation' ~ 'fa-hospital-o',
                                                            Industry..ANZSIC4..description == 'Pubs, Taverns and Bars' ~ 'fa-glass'
                          ),
                          
                          library='fa'),
                          label=~Industry..ANZSIC4..description,
                          popup=~popup,
                          clusterOptions = markerClusterOptions()
        )
    }
    else{
      data <-subset(dfx, dfx$Theme %in% input$theme)
      
      fig <- leaflet(data) %>%
        addProviderTiles(providers$CartoDB) %>%
        addMarkers(lng = ~Longitude, lat = ~Latitude,
                   popup = ~paste0("Theme: ",Theme,
                                   "<br/>Sub Theme: ",
                                   Sub.Theme,"<br/>Feature name: ", Feature.Name), icon = ~iconSet[Theme],
                   clusterOptions = markerClusterOptions())
    }
    
    fig
  })
  
  
  
  
  output$graph <- renderPlotly({
    #get the user imnput data for the map
    selected_theme <- reactive({input$theme})
    #data 
    data <-subset(themes, themes$Theme %in% input$theme)
    #create w plot showing the number of themes
    
    plot_ly(data, x = ~Theme, y = ~Frequency, type = 'bar', hovertext = ~Theme)%>%
      #define map layout
      layout(showlegend = FALSE, title = "Attraction places in city area", plot_bgcolor='#e5ecf6',
             yaxis = list(
               title = 'Number of attractions',
               zerolinecolor = '#ffff',
               zerolinewidth = 2,
               gridcolor = 'ffff'),
             xaxis = list(title = 'Type of attraction',
                          tickangle=45, tickfont = list(family='Rockwell', color='black', size=10)))
  })
  
  output$map <- renderLeaflet({
    data <-subset(dfx, dfx$Theme %in% input$theme)
    
    leaflet(data) %>%
      addProviderTiles(providers$CartoDB) %>%
      addMarkers(lng = ~Longitude, lat = ~Latitude,
                 popup = ~paste0("Theme: ",Theme,
                                 "<br/>Sub Theme: ",
                                 Sub.Theme,"<br/>Feature name: ", Feature.Name), icon = ~iconSet[Theme])
  })

} ## server ends


#############
# RUN SHINY #
#############
shinyApp(ui, server)
